library(testthat)
library(BayesModel)

test_check("BayesModel")
