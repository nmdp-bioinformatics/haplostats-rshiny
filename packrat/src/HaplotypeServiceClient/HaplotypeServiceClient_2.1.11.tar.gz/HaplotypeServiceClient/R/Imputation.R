library(httr)

#' @title createRequestFromMug
#' @details Given population and mug, create a JSON request body.
#'
#' @param population Population to search in
#' @param mug List of alleles
#' @param loci Default NA will return 6 locus A B C DRBX DRB1 DQB1, other choices include 'A~B~DRB1', 'B~C', ...
#'
#' @return JSON representation of imputation request
#'
#' @importFrom rjson toJSON
#'
createRequestFromMug <- function(population, mug, loci) {

  if (is.null(population) || nchar(population) < 3) {
    return(NULL)
  }
  if (is.null(mug)) {
    return(NULL)
  }

  mug <- fixBPR(mug)

  # 1. Populations
  populations <- gsub('UNK', 'CAU', population)
  if (length(population) == 1) {
    populations <- list(populations)
  }
  # Assemble populations and HLA data
  if (is.na(loci)) {
    hla <- list(populations = populations, hlaMUG = mug)
  } else {
    hla <- list(populations = populations, haplotypeLoci = loci, hlaMUG = mug)
  }

  requestBody <- rjson::toJSON(hla)

  debugModeOn <- getOption("debug.haplotypeservice.client")
  if (!is.null(debugModeOn) && debugModeOn) {
    cat(requestBody)
  }

  requestBody
}

#' @title imputeForMug
#' @description Returns a Imputation List
#' @details Takes in a population and MUG and returns a list of probable
#' haplotypes and their frequencies
#'
#' @param population Population to search in
#' @param mug List of alleles
#' @param host Hostname and Port Number of the Server
#' @param loci Default NA will return 6 locus A B C DRBX DRB1 DQB1, other choices include 'A~B~DRB1', 'B~C', ...
#'
#' @return List of probable haplotypes and their frequencies in the given population
#'
#' @importFrom httr POST content_type_json accept_json status_code content
#'
#' @examples
#' \dontrun{
#' mug <- getMugForRID(1419426,'http://p1mri-s1:8080')[[1]]
#'
#' imputeForMug("CAU",mug,'http://p1mri-s1:8080')
#' }
#'
#' @export
#'

imputeForMug <- function(population, mug, host, loci = NA) {
  requestBody <- createRequestFromMug(population, mug, loci)
  if (is.null(requestBody)) return(list(result = NULL, errorStatus = TRUE))
  mugLoci <- sort(unlist(lapply(mug, function(l){
    this<-l$locus
    if (this=='BPR'){this='B'}
    this
  })))
  if (length(mugLoci)==2 && 'B' %in% mugLoci && 'C' %in% mugLoci && loci=='B~C') {
    path = 'impute/haplotype/bc'
  }else {
    path = 'impute/haplotype'
  }
  response <-
    httr::POST(
      url = host, path = path, body = requestBody,
      httr::content_type_json(), httr::accept_json()
    )
  if (httr::status_code(response) == 200) {
    result <- httr::content(response, as = 'parsed')
    imputedHaplotypes <- result$imputedHaplotypes
    # If there are not any matching pairs, the result is empty but is still
    # a successful call.
    if (is.null(imputedHaplotypes) || length(result) == 0 || length(imputedHaplotypes) == 0) {
      return(list(result = data.frame(), errorStatus = FALSE))
    }
    haplotypes <-
      sapply(imputedHaplotypes, function(imputedHaplotype) {
        c(imputedHaplotype$haplotype, imputedHaplotype$population, imputedHaplotype$frequency)
      })
    df <- as.data.frame(t(haplotypes), stringsAsFactors = FALSE)
    names(df) <- c("Haplotype", "Population", "Frequency")
    df$Frequency <- as.numeric(df$Frequency)
    if (loci %in% c('A~B~C', 'A~B~C~DRB1~DQB1')){
      df<-condenseLoci(df,loci,'haplo')
    }
    return(list(result = df, errorStatus = FALSE))
  }

  statusCode <- httr::status_code(response)
  message <- paste("Failed with status:", statusCode);
  warnings(message)
  print(message)

  return(list(result = NULL, errorStatus = TRUE))
}

#
#
imputePairServerRequest <- function(requestBody, mug,host, loci) {
  mugLoci <- sort(unlist(lapply(mug, function(l){
    this<-l$locus
    if (this=='BPR'){this='B'}
    this
  })))
  if (length(mugLoci)==2 && 'B' %in% mugLoci && 'C' %in% mugLoci && loci=='B~C') {
    path = 'impute/haplotype-pairs/bc'
  }else {
    path = 'impute/haplotype-pairs'
  }
  response <-
    httr::POST(
      url = host, path = 'impute/haplotype-pairs', body = requestBody,
      httr::content_type_json(), httr::accept_json()
    )

  if (httr::status_code(response) == 200) {
    result <- httr::content(response, as = 'parsed')
    imputedHaplotypePairs <- result$imputedHaplotypePairs
    # If there are not any matching pairs, the result is empty but is still
    # a successful call.
    if (is.null(imputedHaplotypePairs) || length(imputedHaplotypePairs) == 0) return(list(result = data.frame(), errorStatus = FALSE, 'trs' = 0))

    haplotypePairs <-
      sapply(imputedHaplotypePairs, function(imputedHaplotypePair) {
        c(imputedHaplotypePair$haplotype1$haplotype, imputedHaplotypePair$haplotype1$population, imputedHaplotypePair$haplotype1$frequency,
          imputedHaplotypePair$haplotype2$haplotype, imputedHaplotypePair$haplotype2$population, imputedHaplotypePair$haplotype2$frequency,
          imputedHaplotypePair$frequency)
      })

    df <- as.data.frame(t(haplotypePairs), stringsAsFactors = FALSE)
    names(df) <- c("Haplotype1", "Race1", "Frequency1", "Haplotype2", "Race2", "Frequency2", "Pair Frequency")
    df$Frequency1 <- as.numeric(df$Frequency1)
    df$Frequency2 <- as.numeric(df$Frequency2)

    if (loci %in% c('A~B~C', 'A~B~C~DRB1~DQB1')) {
      df <- condenseLoci(df,loci,'pairs')
    }

    trs <- calculateTRS(as.numeric(df$'Pair Frequency'))

    return(list(result = df, errorStatus = FALSE, 'trs' = trs))
  }

  statusCode <- httr::status_code(response)
  message <- paste("Failed with status:", statusCode);
  warnings(message)
  print(message)

  return(list(result = NULL, errorStatus = TRUE, 'trs' = 0))
}


#' @title imputePairForMug
#' @description Returns a Imputation pairs List
#' @details Takes in a population and MUG and returns a list of probable
#'  haplotype pairs and their frequencies
#'
#' @param population Population to search in
#' @param mug List of alleles
#' @param host Hostname and Port Number of the Server
#' @param loci Default NA will return 6 locus A B C DRBX DRB1 DQB1, other choices include 'A~B~DRB1', 'B~C', "DRB1~DQB1","A~C~B~DRB1" ('A~B~C' and 'A~B~C~DRB1~DQB1' are also available)
#'
#' @return List of probable haplotype pairs and their frequencies in the given population and error check and a TRS score
#'
#' @importFrom httr POST content_type_json accept_json status_code content
#'
#' @examples
#' \dontrun{
#' mug <- getMugForRID(1419426,'http://p1mri-s1:8080')[[1]]
#'
#' imputePairForMug("CAU",mug,'http://p1mri-s1:8080')
#' }
#'
#' @export
#'
imputePairForMug <- function(population, mug, host,loci=NA) {
  requestBody <- createRequestFromMug(population, mug, loci)
  if (is.null(requestBody)) return(list(result = NULL, errorStatus = TRUE, 'trs' = 0))
  return(imputePairServerRequest(requestBody, mug, host, loci))
}

#' @title createRequestFromGLString
#' @details Given population and mug, create a JSON request body.
#'
#' @param population Population to search in
#' @param mug List of alleles
#' @param loci Default NA will return 6 locus A B C DRBX DRB1 DQB1, other choices include 'A~B~DRB1', 'B~C', ...
#'
#' @return JSON representation of imputation request
#'
#' @importFrom rjson toJSON
#'
createRequestFromGLString <- function(population, glstring, loci) {

  if (is.null(population) || nchar(population) < 3) {
    return(NULL)
  }
  if (is.null(glstring)) {
    return(NULL)
  }

  # 1. Populations
  populations <- gsub('UNK', 'CAU', population)
  if (length(population) == 1) {
    populations <- list(populations)
  }
  # Assemble populations and HLA data
  if (is.na(loci)) {
    hla <- list(populations = populations, glString = glstring)
  } else {
    hla <- list(populations = populations, haplotypeLoci = loci, glString = glstring)
  }

  requestBody <- rjson::toJSON(hla)

  debugModeOn <- getOption("debug.haplotypeservice.client")
  if (!is.null(debugModeOn) && debugModeOn) {
    cat(requestBody)
  }

  requestBody
}

#' @title imputePairForGLString
#' @description Returns a Imputation pairs List
#' @details Takes in a population and MUG glstring and returns a list of probable
#'  haplotype pairs and their frequencies
#'
#' @param population Population to search in
#' @param glstring GLString of the mug
#' @param host Hostname and Port Number of the Server
#' @param loci Default NA will return 6 locus A B C DRBX DRB1 DQB1, other choices include 'A~B~DRB1', 'B~C', "DRB1~DQB1","A~C~B~DRB1" ('A~B~C' and 'A~B~C~DRB1~DQB1' are also available)
#'
#' @return List of probable haplotype pairs and their frequencies in the given population and error check and a TRS score
#'
#' @importFrom httr POST content_type_json accept_json status_code content
#'
#' @examples
#' \dontrun{
#'
#' imputePairForGLString(population, glstring, 'http://p1mri-s1:8080')
#' }
#'
#' @export
#'
imputePairForGLString <- function(population, glstring, host,loci=NA) {
  requestBody <- createRequestFromGLString(population, glstring, loci)
  if (is.null(requestBody)) return(list(result = NULL, errorStatus = TRUE, 'trs' = 0))
  return(imputePairServerRequest(requestBody, host, loci))
}


#' @title imputeSHFPairForMug
#' @description Returns a shf Imputation pairs List
#' @details Takes in a population and MUG and returns a list of probable
#'  haplotype pairs and their frequencies
#'
#' @param population Population to search in
#' @param mug List of alleles
#' @param host Hostname and Port Number of the Server
#' @param loci Default NA will return 6 locus A B C DRBX DRB1 DQB1, other choices include 'A~B~DRB1', 'B~C', "DRB1~DQB1","A~C~B~DRB1"
#'
#' @return List of probable shf haplotype pairs and their frequencies in the given population and error check and a TRS score
#'
#' @importFrom httr POST content_type_json accept_json status_code content
#'
#' @examples
#' \dontrun{
#' mug <- getMugForDID(66282,'http://p1mri-s1:8080')[[1]]
#'
#' imputeSHFPairForMug("CAU",mug,'http://p1mri-s1:8080')
#' }
#'
#' @export
#'


imputeSHFPairForMug <- function(population, mug, host,loci=NA){

  mug <- lapply(mug, function(x){
    if (x$locus=='B'){
      x$locus='BPR'
    }
    x
  })

  requestBody <- createRequestFromMug(population, mug, loci)
  if (is.null(requestBody)) return(list(result = NULL, errorStatus = TRUE, 'trs' = 0))
  response <-
    httr::POST(
      url = host, path = 'impute/shf', body = requestBody,
      httr::content_type_json(), httr::accept_json()
    )

  if (httr::status_code(response) == 200) {
    result <- httr::content(response, as = 'parsed')
    imputedHaplotypePairs <- result$haplotypeFrequencyData$pairedFrequency
    # If there are not any matching pairs, the result is empty but is still
    # a successful call.
    if (is.null(imputedHaplotypePairs) || length(imputedHaplotypePairs) == 0) return(list(result = data.frame(), errorStatus = FALSE, 'trs' = 0))
    haplotypePairs <-
      sapply(imputedHaplotypePairs, function(imputedHaplotypePair) {
        c(concatanateTyping(imputedHaplotypePair$firstHaplotypeFrequency$typing),
          imputedHaplotypePair$firstHaplotypeFrequency$population, imputedHaplotypePair$firstHaplotypeFrequency$frequency,
          concatanateTyping(imputedHaplotypePair$secondHaplotypeFrequency$typing),
          imputedHaplotypePair$secondHaplotypeFrequency$population, imputedHaplotypePair$secondHaplotypeFrequency$frequency,
          imputedHaplotypePair$totalFrequency)
      })
    df <- as.data.frame(t(haplotypePairs), stringsAsFactors = FALSE)
    names(df) <- c("Haplotype1", "Race1", "Frequency1", "Haplotype2", "Race2", "Frequency2", "Pair Frequency")
    df$Frequency1 <- as.numeric(df$Frequency1)
    df$Frequency2 <- as.numeric(df$Frequency2)

    trs <- calculateTRS(as.numeric(df$'Pair Frequency'))

    return(list(result = df, errorStatus = FALSE, 'trs' = trs))
  }

  statusCode <- httr::status_code(response)
  message <- paste("Failed with status:", statusCode);
  warnings(message)
  print(message)

  return(list(result = NULL, errorStatus = TRUE, 'trs' = 0))
}



concatanateTyping <- function(typing){
  paste0(paste0(names(typing),'*',typing),collapse = '~')
}

fixBPR <- function(mug) {
  for (i in 1:length(mug)) {
    if (mug[[i]]$locus == 'B') {
      mug[[i]]$locus <- 'BPR'
    }
  }
  mug
}

# Typing Resolution Score for the imputation
calculateTRS <- function(freqs){
  if (length(freqs)>0){
      p <- freqs/(sum(freqs))
      return(sum(p^2))
  }
  0
}


condenseLoci <- function(df, loci, type){

  if (type=='pairs'){

      lociList <- unlist(strsplit(loci,'~'))
      hap1 <- removeLoci(df$Haplotype1,lociList)
      hap2 <- removeLoci(df$Haplotype2,lociList)
      freq1 <- df$Frequency1
      freq2 <- df$Frequency2
      race1 <- df$Race1
      race2 <- df$Race2

      uniHap1 <- unique(hap1)
      uniHap2 <- unique(hap2)

      if (length(uniHap1)==length(hap1) && length(uniHap2)==length(hap2)){
        condenseDF <- df
        condenseDF$Haplotype1=hap1
        condenseDF$Haplotype2=hap2
        return (condenseDF)
      }

      genotypes <- getGenoTypes(hap1,hap2, freq1, freq2, race1, race2)

      condenseDF <- condenseGenotypes(genotypes,df)

      return (condenseDF)

  } else if (type=='haplo') {

    lociList <- unlist(strsplit(loci,'~'))
    hap <- removeLoci(df$Haplotype,lociList)
    freq <- df$Frequency
    race <- df$Population

    uniHap <- unique(hap)

    if (length(uniHap)==length(hap)){
      condenseDF <- df
      condenseDF$Haplotype=hap
      return (condenseDF)
    }

    haplotypes <- df
    haplotypes$Haplotype <- paste0(hap,race)

    condenseDF <- condenseHaplotypes(haplotypes)
    condenseDF$Haplotype <- uniHap
    return(condenseDF)

  }

}

removeLoci <- function(hap, lociList){
  if ('DRBX' %in% lociList) {
    xind=which(lociList=='DRBX')
    lociList=c(lociList[-xind],c( 'DRB3', 'DRB4', 'DRB5'))
    }
  lociOptions <- c('A', 'B', 'DRB1', 'C', 'DQB1', 'DRB3', 'DRB4', 'DRB5')
  lociinds<-match(lociList,lociOptions)
    return(
      unlist(lapply(hap,function(x){
       paste0(unlist(strsplit(x,'~'))[lociinds],collapse='~')
      }))
    )
}

getGenoTypes <- function(hap1,hap2, freq1, freq2, race1, race2){
  genoList = data.frame(matrix(NA,nrow=length(hap1), ncol=7))
  for (h in 1:length(hap1)){
    pair <- c(hap1[h],hap2[h])
    freqs <-c(freq1[h],freq2[h])
    races <- c(race1[h], race2[h])
    inds <- order(pair)
    thisGeno <- paste0(pair[inds],races[inds],collapse='-')
    genoList[h,]<-c(thisGeno,pair[inds],freqs[inds],races[inds])
  }
  names(genoList)=c('Pair',"Haplotype1","Haplotype2","Frequency1","Frequency2","Race1","Race2")
  genoList
}

condenseGenotypes <- function(genotypes,df){

  uniGenos<-unique(genotypes$Pair)
  newdf=data.frame(matrix(nrow=length(uniGenos), ncol=7))

  for (g in 1:length(uniGenos)){
    thisgeno<- uniGenos[g]
    subdata <- genotypes[which(genotypes$Pair==thisgeno),]
    if(nrow(subdata)>1){
      tmp <- subdata
      subdata <- subdata[1,]
      subdata$Frequency1=sum(as.numeric(tmp$Frequency1))
      subdata$Frequency2=sum(as.numeric(tmp$Frequency2))
    }
    colInds <- match(names(df)[1:6],names(subdata))
    newdf[g,1:6]=subdata[colInds]
    newdf[g,7]=as.numeric(subdata$Frequency1)*as.numeric(subdata$Frequency2)
  }
  names(newdf)=names(df)
  return(newdf)
}

condenseHaplotypes <- function(haplotypes){

  uniHap<- unique(haplotypes$Haplotype)

  newdf=data.frame(matrix(nrow=length(uniHap), ncol=3))

  for (h in 1:length(uniHap)){
    thishap<- uniHap[h]
    subdata <- haplotypes[which(haplotypes$Haplotype==thishap),]
    if(nrow(subdata)>1){
      tmp <- subdata
      subdata <- subdata[1,]
      subdata$Frequency=sum(as.numeric(tmp$Frequency))
    }
    newdf[h,]=subdata
  }
  names(newdf)=names(haplotypes)
  return(newdf)
}
