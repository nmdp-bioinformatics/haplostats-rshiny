
httpHeaders <- c(Accept = "application/json",
                 'Content-Type' = 'application/json;charset=UTF-8')

#' @title getSireForDID
#' @description Returns a Sire for a given DID
#' @details Takes in a DID and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param did Patient ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return sire Returns a vector of all self identified Broad Race groups,
#'    returns \code{NULL} if \code{did} is not found.
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#' sire <- getSireForDID(95963823,'http://p1mri-s1:8080')
#' }
#'
#' @export
getSireForDID <- function(did, host){

  # build the complete URL
  url = paste(host, '/sire/did/', did, sep='')

  resultJSON <- NULL
  tryCatch(
    # Get SIRE from the server
    resultJSON <- RCurl::getURL(url, httpheader= httpHeaders),
    error = function(e) {
      message(paste("Failed calling the service at URL", url))
    }

  )

  if(!is.null(resultJSON) && nchar(resultJSON) > 0) {
    result <- rjson::fromJSON(resultJSON)
    return(result)

  }
  NULL
}


#' @title getDetailedForDID
#' @description Returns a Detailed Race for a given DID
#' @details Takes in a DID and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param did Patient ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return detailed Returns the detailed race and ethnicity,
#'    returns \code{NULL} if \code{did} is not found.
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#' detailed <- getDetailedForDID(95963823,'http://p1mri-s1:8080')
#' }
#'
#' @export
getDetailedForDID <- function(did, host){

  # build the complete URL
  url = paste(host, '/hla/did/', did, sep='')

  resultJSON <- NULL
  tryCatch(
    # Get SIRE from the server
    resultJSON <- RCurl::getURL(url, httpheader= httpHeaders),
    error = function(e) {
      message(paste("Failed calling the service at URL", url))
    }

  )

  if(!is.null(resultJSON) && nchar(resultJSON) > 0) {
    result <- rjson::fromJSON(resultJSON)
    race=result$race
    ethn=result$ethnicity
    population=result$population

    return(c(race,ethn, population))
  }
  NULL
}

