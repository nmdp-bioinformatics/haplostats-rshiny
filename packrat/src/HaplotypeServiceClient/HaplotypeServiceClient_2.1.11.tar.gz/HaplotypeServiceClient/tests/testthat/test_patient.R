


test_that("info by RID", {

  rid <- 1419426
  host <- "http://p1mri-s1:8080"

  info <- getPatientInfoRID(rid, host)

  expect_false(is.null(info))
  expect_true(is.list(info))
  #expect_true(length(info) == 13)


})



test_that("info by list of guids", {

  guids <- c("8c15295c38204fc1ab4ced5898579092", "c659fd63f65f4e8a84d4ed5898579092",
             "04563b7777ce483e9848ed5898579092", "7cf0cde737d74e2099faed5898579092",
             "78e3f4960a2041d6af0ded5898579092", "958ed04e28e0430d99f3ed5898579092",
             "d52ed84ba908445cad96ed5898579092", "f1a612fee27645f1b5d4ed5898579092",
             "ef1c22a58e57421a9dcded5898579092", "f41e133fdfa54a838316ed5898579092",
             "b10fa9d5a2da40c7ba0ded5898579092", "3cc5cb8735e94cca9607ed5898579092")
  host <- "http://p1mri-s1:8080"

  info <- getInfoGUIDs(guids, host)

  expect_false(is.null(info))
  expect_true(is.list(info))
  #expect_true(length(info) == 13)


})

test_that("info by list of guids with bad one", {

  guids <- c("8c15295c38204fc1ab4ced5898579092", "c659fd63f65f4e8a84d4ed5898579092",
             "04563b7777ce483e9848ed5898579092", "7cf0cde737d74e2099faed5898579092",
             "78e3f4960a2041d6af0ded5898579092", "958ed04e28e0430d99f3ed5898579092",
             "d52ed84ba908445cad96ed5898579092", "f1a612fee27645f1b5d4ed5898579092",
             "ef1c22a58e57421a9dcded5898579092", "f41e133fdfa54a838316ed5898579092",
             "b10fa9d5a2da40c7ba0ded5898579092", "3cc5cb8735e94cca9607ed5898579092",
             "517c2340e04f60a4e2ed5898579092")
  host <- "http://p1mri-s1:8080"

  info <- getInfoGUIDs(guids, host)

  expect_false(is.null(info))
  expect_true(is.list(info))
  #expect_true(length(info) == 13)
  expect_true(info[["517c2340e04f60a4e2ed5898579092"]]$errorStatus)

})
