SERVER_URL <- "http://p1mri-s1:8080"


# Test By ID ----------------------------------------------------------------

test_that('Detailed by CID', {
  cid <- 999807689
  sire <- getDetailedForCID(cid, SERVER_URL)
  expect_false(is.null(sire))
})

test_that("DETAILED by RID", {

  rid <- 1419426
  host <- SERVER_URL

  sire <- getDetailedForRID(rid, host)

  expect_false(is.null(sire))


})

test_that("DETAILED with Invalid RID", {
  rid <- 8888899999
  host <- SERVER_URL

  sire <- getDetailedForRID(rid, host)

  expect_null(sire)
})

test_that("DETAILED with Invalid host", {
  rid <- 1419426
  host <- "http://testurl.nmdp.org:9988"

  expect_message(sire <- getDetailedForRID(rid, host), "Failed")
  expect_null(sire)

})

# Test by Guid ----------------------------------------------------------------------------------------------------

test_that("DETAILED by patient Guid", {

  guid <- "b57a1cc37f594a81870d263dbb929e71"
  host <- "http://p1mri-s1:8080"

  sire <- getDetailedForGuid(guid, host)

  expect_false(is.null(sire))


})

test_that("DETAILED by donor Guid", {

  guid <- "6be6b79703bf4f38a7f9ed5898579092"
  host <- "http://p1mri-s1:8080"

  sire <- getDetailedForGuid(guid, host)

  expect_false(is.null(sire))


})

test_that("DETAILED by cord Guid", {

  guid <- "e9c0339ad9da33ade040970a0e8579ba"
  host <- "http://p1mri-s1:8080"

  sire <- getDetailedForGuid(guid, host)

  expect_false(is.null(sire))


})

test_that("DETAILED with Invalid Guid", {
  guid <- 8888899999
  host <- "http://p1mri-s1:8080"

  sire <- getDetailedForGuid(guid, host)
  expect_null(sire)
})

# test_that("DETAILED with Invalid host", {
#   guid <- "b57a1cc37f594a81870d263dbb929e71"
#   host <- "http://testurl.nmdp.org:9988"
#
#   sire <- tryCatch({
#     sire <- getDetailedForGuid(guid, host)
#     fail("Failed testing ");
#   }, error = function(e) {
#     expect_true(grep("Couldn't resolve host name", e$message) > 0)
#     NULL
#   })
#   expect_null(sire)
# })


# Test SIRE ----------------------------------------------------------------

test_that('Sire by CID', {
  cid <- 999807689
  sire <- getSireForCID(cid, SERVER_URL)
  expect_false(is.null(sire))
})

test_that("SIRE by RID", {

  rid <- 1419426
  host <- SERVER_URL

  sire <- getSireForRID(rid, host)

  expect_false(is.null(sire))


})

test_that("SIRE with Invalid RID", {
  rid <- 8888899999
  host <- SERVER_URL

  sire <- getSireForRID(rid, host)

  expect_null(sire)
})

# test_that("SIRE with Invalid host", {
#   rid <- 1419426
#   host <- "http://testurl.nmdp.org:9988"
#
#   sire <- tryCatch({
#     sire <- getSireForRID(rid, host)
#     fail("Failed testing ");
#   }, error = function(e) {
#     expect_true(grep('Failed', e$message) > 0)
#     NULL
#   })
#   expect_null(sire)
#
# })

# Test Sire by Guid -----------------------------------------------------------------------------------------------

test_that("SIRE by patient Guid", {

  guid <- "b57a1cc37f594a81870d263dbb929e71"
  host <- "http://p1mri-s1:8080"

  sire <- getSireForRecipientGuid(guid, host)

  expect_false(is.null(sire))
  expect_equal(sire$id, guid)
  expect_equal(sire$races[[1]], 'CAU')
  expect_equal(sire$ethnicity, 'NHIS')


})

test_that("SIRE by donor Guid", {

  guid <- "6be6b79703bf4f38a7f9ed5898579092"
  host <- "http://p1mri-s1:8080"

  sire <- getSireForDonorGuid(guid, host)

  expect_false(is.null(sire))
  expect_equal(sire$id, guid)
  expect_equal(sire$races[[1]], 'CAU')
  expect_null(sire$ethnicity)

})

test_that("Multiple SIRE by donor Guid", {

  guid <- "2985c8419aa1432bbf75efbc51d66cc8"
  host <- "http://p1mri-s1:8080"

  sire <- getSireForDonorGuid(guid, host)

  expect_false(is.null(sire))
  expect_equal(sire$id, guid)

  races <- sort(unlist(sire$races))
  expect_equal(races[1], 'AMIND')
  expect_equal(races[2], 'NAMER')

  expect_equal(sire$ethnicity, 'NHIS')
})

test_that("SIRE by cord Guid", {

  guid <- "e9c0339ad9da33ade040970a0e8579ba"
  host <- "http://p1mri-s1:8080"

  sire <- getSireForCbuGuid(guid, host)

  expect_false(is.null(sire))
  expect_equal(sire$id, guid)
  expect_equal(sire$races[[1]], 'DEC')
  expect_null(sire$ethnicity)
})

test_that("SIRE with Invalid Guid", {
  guid <- 8888899999
  host <- "http://p1mri-s1:8080"

  sire <- getSireForRecipientGuid(guid, host)
  expect_null(sire)
})
