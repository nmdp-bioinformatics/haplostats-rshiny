SERVER_URL <- "http://p1mri-s1:8080"
##SERVER_URL<- "http://b3haplogic-s1.nmdp.org:28080"


# Prepare the request to the webservice.  1. Population
population <- "AFA"
# 2. HLA data
s1 <- list(locus = "A", type1 = "31:01", type2 = "66:01")
s2 <- list(locus = "BPR", type1 = "40:02", type2 = "41:02")
s3 <- list(locus = "C", type1 = "03:04", type2 = "17:03")
s4 <- list(locus = "DRB1", type1 = "07:01", type2 = "04:04")
s5 <- list(locus = "DQB1", type1 = "03:02", type2 = "02:01")
mug <- list(s1, s2, s3, s4, s5)


test_that("Impute by mug and sire", {
  host <- SERVER_URL
  imputationList <- imputeForMug(population, mug, host)

  expect_false(is.null(imputationList))
})

test_that("Population is empty", {
  host <- SERVER_URL
  imputationList <- imputeForMug(population = "", mug, host)

  expect_null(imputationList$result)
  expect_true(imputationList$errorStatus)
})

test_that("Population is null", {
  host <- SERVER_URL
  imputationList <- imputeForMug(population = NULL, mug, host)

  expect_null(imputationList$result)
  expect_true(imputationList$errorStatus)
})

test_that("Population is UNK", {
  host <- SERVER_URL
  imputationList <- imputeForMug(population = "UNK", mug, host)

  expect_false(is.null(imputationList)[[1]])
})

test_that("Multiple Population ", {
  host <- SERVER_URL
  population <- c("AFA", "CAU")
  imputationList <- imputeForMug(population = population, mug, host)
  # Multiple populations are fine
  expect_false(is.null(imputationList$result))
  # Will only use the first one (AFA)
  expect_true(all(imputationList$result$Population == 'AFA'))
})

test_that("Mug is NULL", {
  host <- SERVER_URL

  imputationList <- imputeForMug("CAU", mug = NULL, host)
  expect_null(imputationList$result)

})

test_that("Imputation of mug from getMugForRID", {
  rid <- 1419426
  host <- SERVER_URL
  mug <- getMugForRID(rid, host)[[1]]
  imputationList <- imputeForMug("CAU", mug, host)

  expect_true(is.list(imputationList$result))
})


test_that("Imputation of mug with no results", {
  rid <- 1419426
  host <- SERVER_URL
  mug <- getMugForRID(rid, host)[[1]]
  imputationList <- imputeForMug("KORI", mug, host)

  expect_false(is.null(imputationList$result))
  expect_true(is.data.frame(imputationList$result))
  expect_equal(nrow(imputationList$result), 0)
  expect_false(imputationList$errorStatus)
})

test_that("Impute pair by mug and sire not null", {
  host <- SERVER_URL
  imputationList <- imputePairForMug(population, mug, host)

  expect_false(is.null(imputationList$result))
})

test_that("Impute pair by mug and sire returns pairs", {
  host <- SERVER_URL
  imputationList <- imputePairForMug(population, mug, host)

  expect_false(is.null(imputationList$result))
  expect_more_than(nrow(imputationList$result), 0)
  expect_named(imputationList$result,
               c("Haplotype1", "Race1", "Frequency1",  "Haplotype2", "Race2", "Frequency2", "Pair Frequency"))
})

test_that("Impute pair by mug and population that returns no result", {
  host <- SERVER_URL
  imputationList <- imputePairForMug('KORI', mug, host)

  expect_false(is.null(imputationList$result))
  expect_equal(nrow(imputationList$result), 0)
  expect_false(imputationList$errorStatus)
})

test_that("Impute shf pair by mug and sire returns pairs", {
  host <- SERVER_URL
  mug2 <- getMugForDID(66282,'http://p1mri-s1:8080')[[1]]
  imputationList <- imputeSHFPairForMug('CAU', mug2, host)

  expect_false(is.null(imputationList$result))
  expect_more_than(nrow(imputationList$result), 0)
  expect_named(imputationList$result,
               c("Haplotype1", "Race1", "Frequency1",  "Haplotype2", "Race2", "Frequency2", "Pair Frequency"))
})

test_that("Impute pair by mug and sire returns pairs", {
  population <- c("AFA", "CAU", "AINDI")
  glstring <- "A*31:01+A*66:01^C*03:04+C*17:03^B*40:02+B*41:02^DRB1*04:04+DRB1*07:01^DQB1*02:01+DQB1*03:02"
  host <- SERVER_URL
  host <- 'http://b1haplogic-s3:8080'
  imputationList <- imputePairForGLString(population, glstring, host)

  expect_false(is.null(imputationList$result))
  expect_more_than(nrow(imputationList$result), 0)
  expect_named(imputationList$result,
               c("Haplotype1", "Race1", "Frequency1",  "Haplotype2", "Race2", "Frequency2", "Pair Frequency"))
})


