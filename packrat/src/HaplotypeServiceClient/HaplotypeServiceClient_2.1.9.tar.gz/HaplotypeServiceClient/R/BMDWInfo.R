#' @title getBMDWInfoGUID
#' @description Returns available information for a bmdw source with a given GUID
#' @details Takes in a guid and a host:port and accesses the server to get the corresponding
#'  BMDW data returning mug, race ethnicity, patient guid, and an error status if there was a problem
#'
#'  @param guid BMDW subject GUID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return info List of the mug, race ethnicity, source guid, and an error status
#'
#' @importFrom httr GET accept_json status_code content
#'
#' @examples
#' \dontrun{
#' info <- getBMDWInfoGUID('3410b59a5ede41988a388150a65ed658','http://p1mri-s1:8080')
#' }
#'
#' @export
#'
getBMDWInfoGUID <- function(guid, host) {

  response <- httr::GET(url = host, path = paste0('hla/bmdw/guid/', guid),
                        httr::accept_json())

  if (httr::status_code(response) == 200) {
    result <- httr::content(response, as = 'parsed', encoding = 'json')

    searchTypings <- result$searchTypings
    mug <- list()
    for(i in 1:length(searchTypings)) {
      locus <- searchTypings[[i]]$hlaLocus
      # Haplogic uses BPR, turn it into B
      if(locus == 'BPR') locus <- 'B'
      type1 <- searchTypings[[i]]$antigen1
      if( is.null(type1) || type1 == "null") {
        type1 <- ""
      }
      type2 <- searchTypings[[i]]$antigen2
      if( is.null(type2) || type2 == "null") {
        type2 <- ""
      }
      s <- list(locus=locus, type1=type1, type2=type2)
      mug[[i]] <- s
    }

    race <- result$race
    ethn <- result$ethnicity
    racethn <- c(race, ethn)
    age <- result$age
    rhType <- result$rhType
    bloodType <- result$bloodType
    weightInKg <- result$weightInKg
    status <- result$nmdpStatus
    cmvStatus <- result$cmvStatus
    totalNucleatedCellCount <- result$totalNucleatedCellCount
    sex <- result$sex
    population<-result$population
    id <- result$nmdpId
    lastContact <- result$lastDonorContactDate
    cd34 <- result$cd34
    businessParty<- result$businessParty
    bmdwCount <- result$bmdwCount

    guid <- result$subjectId

    info <- list('id' = id, 'mug'=mug, 'racethn'=racethn, 'guid'=guid, 'age' = age, 'sex'=sex,
                 'rhType' = rhType, 'status'=status,'bloodType' = bloodType,'weightInKg' = weightInKg,
                 'cmvStatus'=cmvStatus, 'totalNucleatedCellCount'=totalNucleatedCellCount,'population'=population,
                 'lastContact'=lastContact, 'cd34'=cd34, 'businessParty'=businessParty, 'bmdwCount'=bmdwCount,
                 'errorStatus'=FALSE)

    return(info)
  } else {
    info <- list('id' = NA, 'mug'=NA, 'racethn'=NA, 'guid'=guid, 'age' = NA, 'sex'=NA,
                 'rhType' = NA, 'status'=NA,'bloodType' = NA,'weightInKg' = NA,
                 'cmvStatus'=NA,'totalNucleatedCellCount'=NA,'population'=NA,
                 'lastContact'=NA, 'cd34'=NA,'businessParty'=NA, 'bmdwCount'=NA,
                 'errorStatus'=TRUE)
    return(info)
  }

  NULL
}


#' @title getBMDWInfoGUIDs
#' @description Returns available information for a list of bmdw sources with GUIDs
#' @details Takes in a guid and a host:port and accesses the server to get the corresponding
#'  bmdw source data returning mug, race ethnicity, patient guid, and an error status if there was a problem
#'
#'  @param guids list of BMDW source GUIDs
#'  @param host Hostname and Port Number of the Server
#'
#'  @return info List of the mug, race ethnicity, source guid, and an error status
#'
#' @importFrom httr POST
#' @importFrom rjson toJSON
#'
#' @examples
#' \dontrun{
#' guids <- c(
#' "d2c476f5feb64ffdaa12e786fdf2036a",
#' "3410b59a5ede41988a388150a65ed658",
#' "698b325fe566408f97e6ad8f5f3001d5",
#' "c5df246c58e8497291f52dac303b7e26",
#' "2d56eb271ef04d8a97ebed5898579092"
#' )
#' info <- getBMDWInfoGUIDs(guids,'http://p1mri-s1:8080')
#' }
#'
#' @export
#'
getBMDWInfoGUIDs <- function(guids, host) {

  requestBody <- rjson::toJSON(guids)
  response <- httr::POST(host, path = 'hla/bmdw/guids', body = requestBody, httr::content_type_json(), httr::accept_json())

  if (httr::status_code(response) == 200) {
    resultList <- httr::content(response, as = 'parsed', encoding = 'json')

    fullResults <- list()

    for (d in 1:length(resultList)){

      result <- resultList[[d]]
      guid <- names(resultList)[d]

      if (!is.null(result)){
        searchTypings <- result$searchTypings
        mug <- list()
        for(i in 1:length(searchTypings)) {
          locus <- searchTypings[[i]]$hlaLocus
          # Haplogic uses BPR, turn it into B
          if(locus == 'BPR') locus <- 'B'
          type1 <- searchTypings[[i]]$antigen1
          if( is.null(type1) || type1 == "null") {
            type1 <- ""
          }
          type2 <- searchTypings[[i]]$antigen2
          if( is.null(type2) || type2 == "null") {
            type2 <- ""
          }
          s <- list(locus=locus, type1=type1, type2=type2)
          mug[[i]] <- s
        }

        race <- result$race
        ethn <- result$ethnicity
        racethn <- c(race, ethn)
        age <- result$age
        rhType <- result$rhType
        bloodType <- result$bloodType
        weightInKg <- result$weightInKg
        status <- result$nmdpStatus
        cmvStatus <- result$cmvStatus
        totalNucleatedCellCount <- result$totalNucleatedCellCount
        sex <- result$sex
        population <- result$population
        id <- result$nmdpId
        lastContact <- result$lastDonorContactDate
        cd34 <- result$cd34
        businessParty<- result$businessParty
        bmdwCount <- result$bmdwCount


        info <- list('id' = id, 'mug'=mug, 'racethn'=racethn, 'guid'=guid, 'age' = age, 'sex'=sex,
                     'rhType' = rhType, 'status'=status,'bloodType' = bloodType,'weightInKg' = weightInKg,
                     'cmvStatus'=cmvStatus, 'totalNucleatedCellCount'=totalNucleatedCellCount,'population'=population,
                     'lastContact'=lastContact, 'cd34'=cd34, 'businessParty'=businessParty, 'bmdwCount'=bmdwCount,
                     'errorStatus'=FALSE)
      } else {

        info <- list('id' = NA, 'mug'=NA, 'racethn'=NA, 'guid'=guid, 'age' = NA, 'sex'=NA,
                     'rhType' = NA, 'status'=NA,'bloodType' = NA,'weightInKg' = NA,
                     'cmvStatus'=NA,'totalNucleatedCellCount'=NA, 'population'=NA,
                     'lastContact'=NA, 'cd34'=NA, 'businessParty'=NA, 'bmdwCount'=NA,
                     'errorStatus'=TRUE)
      }

      fullResults[[guid]] <- info
    }

    return(fullResults)
  }

  NULL
  }
