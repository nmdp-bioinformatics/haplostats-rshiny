host<-'http://b3haplogic-s1.nmdp.org:28080'

test_that("Get Info for a list of guids and make sure the results are retuned in the same order", {
  guids <- read.csv('guids-req.txt', stringsAsFactors = FALSE)[[1]]
  expect_equal(length(guids), 99)
  guidInfos <- getInfoGUIDs(guids, host)
  guidsFromServer <- unlist(lapply(guidInfos, function(info) info$guid))
  names(guidsFromServer)  <- NULL
  expect_equal(length(guidsFromServer), 99)
  expect_equal(guids, guidsFromServer)
})


# test_that("Get Info for a longer list of guids and make sure the results are retuned in the same order", {
#   guids <- read.csv('guidlist.csv', stringsAsFactors = FALSE)[,2]
#   expect_equal(length(guids), 2116)
#   guidInfos <- getInfoGUIDs(guids, host)
#   guidsFromServer <- unlist(lapply(guidInfos, function(info) info$guid))
#   names(guidsFromServer)  <- NULL
#   expect_equal(length(guidsFromServer), 2116)
#   expect_equal(guids, guidsFromServer)
# })
