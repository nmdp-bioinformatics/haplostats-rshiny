MUG_SERVER <- "http://p1mri-s1:8080"

# Not a very good test, because the RID is from production.
test_that("Mug by RID", {

  rid <- 1419426
  host <- MUG_SERVER

  mug <- getMugForRID(rid, host)[[1]]

  expect_false(is.null(mug))
  expect_true(is.list(mug))

  loci <- sapply(mug, function(l) l$locus)
  expect_equal(sort(loci), c("A", "B", "C", "DQB1", "DRB1", "DRB4"))

})

test_that("Mug with Invalid RID", {
  rid <- 8888899999
  host <- MUG_SERVER

  result <- getMugForRID(rid, host)
  mug <- result[[1]]
  error <- result[[2]]

  expect_null(mug)
  expect_true(error)
})

test_that("Mug with Invalid host", {
  rid <- 1419426
  host <- "http://testurl.nmdp.org:9988"

  expect_message(mug <- getMugForRID(rid, host), "Failed")

})




############ GUID tests




test_that("Patient Mug by Guid", {

  guid <- "b57a1cc37f594a81870d263dbb929e71"
  host <- MUG_SERVER
  # host <- 'http://b3haplogic-s1.nmdp.org:8080'

  mug <- getMugForGuid(guid, host)[[1]]

  expect_false(is.null(mug))
  expect_true(is.list(mug))

  loci <- sapply(mug, function(l) l$locus)
  expect_equal(sort(loci), c("A", "B", "C", "DQB1", "DRB1", "DRB4"))

})


test_that("Cord Mug by Guid", {

  guid <- "e9c0339ad9da33ade040970a0e8579ba"
  host <- MUG_SERVER
  # host <- 'http://b3haplogic-s1.nmdp.org:8080'

  mug <- getMugForGuid(guid, host)[[1]]

  expect_false(is.null(mug))
  expect_true(is.list(mug))

  loci <- sapply(mug, function(l) l$locus)
  expect_equal(sort(loci), c("A","B","C","DPB1","DQB1", "DRB1"))

})


test_that("Donor Mug by Guid", {

  guid <- "6be6b79703bf4f38a7f9ed5898579092"
  host <- MUG_SERVER
  # host <- 'http://b3haplogic-s1.nmdp.org:8080'

  mug <- getMugForGuid(guid, host)[[1]]

  expect_false(is.null(mug))
  expect_true(is.list(mug))

  loci <- sapply(mug, function(l) l$locus)
  expect_equal(sort(loci), c("A", "B", "DRB1"))

})



test_that("Mug with Invalid Guid", {
  guid <- 8888899999
  host <- MUG_SERVER
  # host <- 'http://b3haplogic-s1.nmdp.org:8080'

  result <- getMugForGuid(guid, host)
  mug <- result[[1]]
  error <- result[[2]]

  expect_null(mug)
  expect_true(error)
})

test_that("Mug with Invalid host", {
  guid <- "b57a1cc37f594a81870d263dbb929e71"
  host <- "http://testurl.nmdp.org:9988"

  expect_message(mug <- getMugForGuid(guid, host), "Failed")

})

