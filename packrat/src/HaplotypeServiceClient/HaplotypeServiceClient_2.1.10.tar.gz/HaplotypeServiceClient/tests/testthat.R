library(testthat)
library(HaplotypeServiceClient)

test_check("HaplotypeServiceClient")
