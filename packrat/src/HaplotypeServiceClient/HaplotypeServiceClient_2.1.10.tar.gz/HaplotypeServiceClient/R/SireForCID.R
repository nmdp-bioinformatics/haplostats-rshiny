
httpHeaders <- c(Accept = "application/json",
                 'Content-Type' = 'application/json;charset=UTF-8')

#' @title getSireForCID
#' @description Returns a Sire for a given CID
#' @details Takes in a CID and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param cid Patient ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return sire Returns a vector of all self identified Broad Race groups,
#'    returns \code{NULL} if \code{cid} is not found.
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#' sire <- getSireForCID(999807689,'http://p1mri-s1:8080')
#' }
#'
#' @export
getSireForCID <- function(cid, host){

  # build the complete URL
  url = paste(host, '/sire/cid/', cid, sep='')

  resultJSON <- NULL
  tryCatch(
    # Get SIRE from the server
    resultJSON <- RCurl::getURL(url, httpheader= httpHeaders),
    error = function(e) {
      message(paste("Failed calling the service at URL", url))
    }

  )

  if(!is.null(resultJSON) && nchar(resultJSON) > 0) {
    result <- rjson::fromJSON(resultJSON)
    return(result)

  }
  NULL
}



#' @title getDetailedForCID
#' @description Returns a Detailed Race for a given CID
#' @details Takes in a CID and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param cid Patient ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return detailed Returns the detailed race and ethnicity,
#'    returns \code{NULL} if \code{cid} is not found.
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#' detailed <- getDetailedForCID(999807689,'http://p1mri-s1:8080')
#' }
#'
#' @export
getDetailedForCID <- function(cid, host){

  # build the complete URL
  url = paste(host, '/hla/cid/', cid, sep='')

  resultJSON <- NULL
  tryCatch(
    # Get SIRE from the server
    resultJSON <- RCurl::getURL(url, httpheader= httpHeaders),
    error = function(e) {
      message(paste("Failed calling the service at URL", url))
    }

  )

  if(!is.null(resultJSON) && nchar(resultJSON) > 0) {
    result <- rjson::fromJSON(resultJSON)
    race=result$race
    ethn=result$ethnicity
    population=result$population


    return(c(race,ethn,population))
  }
  NULL
}
