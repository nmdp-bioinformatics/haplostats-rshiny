
httpHeaders <- c(Accept = "application/json",
                 'Content-Type' = 'application/json;charset=UTF-8')

#' @title getPatientInfoRID
#' @description Returns a list of data for a patient including for a given RID
#' @details Takes in a RID and a host:port and accesses the server to get the corresponding
#'  patients data returning mug, race ethnicity, patient guid, and an error status if there was a problem
#'
#'  @param rid Patient ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return info List of the mug, race ethnicity, patient guid, and an error status
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#' mug <- getPatientInfoRID(1419426,'http://p1mri-s1:8080')
#' }
#'
#' @export
#'
getPatientInfoRID <- function(rid, host) {
  url <- paste(host, '/hla/rid/', rid, sep='')

  resultJSON <- NULL
  errorStatus <- FALSE

  if ( rid == 'invalid') {
    resultJSON=NULL
  } else {
      tryCatch(
        resultJSON <- RCurl::getURL(url, httpheader= httpHeaders),
        error = function(e) {
          message(paste("Failed calling the service at URL", url))
          errorStatus <- TRUE
        })
  }

  if(!is.null(resultJSON) && nchar(resultJSON) > 0) {
    result <- rjson::fromJSON(resultJSON)
    searchTypings <- result$searchTypings
    mug <- list()
    for(i in 1:length(searchTypings)) {
      locus <- searchTypings[[i]]$hlaLocus
      # Haplogic uses BPR, turn it into B
      if(locus == 'BPR') locus <- 'B'
      type1 <- searchTypings[[i]]$antigen1
      if( is.null(type1) || type1 == "null") {
        type1 <- ""
      }
      type2 <- searchTypings[[i]]$antigen2
      if( is.null(type2) || type2 == "null") {
        type2 <- ""
      }
      s <- list(locus=locus, type1=type1, type2=type2)
      mug[[i]] <- s
    }

    race <- result$race
    ethn <- result$ethnicity
    racethn <- c(race, ethn)
    age <- result$age
    rhType <- result$rhType
    bloodType <- result$bloodType
    weightInKg <- result$weightInKg
    status <- result$nmdpStatus
    cmvStatus <- result$cmvStatus
    totalNucleatedCellCount <- result$totalNucleatedCellCount
    sex <- result$sex

    guid <- result$subjectId

    info <- list('rid' = rid, 'mug'=mug, 'racethn'=racethn, 'guid'=guid, 'age' = age, 'sex'=sex,
                 'rhType' = rhType, 'status'=status,'bloodType' = bloodType,'weightInKg' = weightInKg,
                 'cmvStatus'=cmvStatus, 'totalNucleatedCellCount'=totalNucleatedCellCount,
                 'errorStatus'=errorStatus)

    return(info)

    } else {

      info <- list('rid' = rid, 'mug'=NA, 'racethn'=NA, 'guid'=NA, 'age' = NA, 'sex'=NA,
                   'rhType' = NA, 'status'=NA,'bloodType' = NA,'weightInKg' = NA,
                   'cmvStatus'=NA,'totalNucleatedCellCount'=NA,
                   'errorStatus'=TRUE)
      return(info)

    }

  NULL

}

#' @title getInfoGUID
#' @description Returns a list of data for a patient including for a given GUID
#' @details Takes in a guid and a host:port and accesses the server to get the corresponding
#'  patients data returning mug, race ethnicity, patient guid, and an error status if there was a problem
#'
#'  @param guid  ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return info List of the mug, race ethnicity, patient guid, and an error status
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#' info <- getInfoGUID('b57a1cc37f594a81870d263dbb929e71','http://p1mri-s1:8080')
#' }
#'
#' @export
#'
getInfoGUID <- function(guid, host) {


  url <- paste(host, '/hla/guid/', guid, sep='')

  resultJSON <- NULL
  errorStatus <- FALSE

  if ( guid == 'invalid') {
    resultJSON=NULL
  } else {
    tryCatch(
      resultJSON <- RCurl::getURL(url, httpheader= httpHeaders),
      error = function(e) {
        message(paste("Failed calling the service at URL", url))
        errorStatus <- TRUE
      })
  }

  if(substr(resultJSON,1,1)=='<') {
    problem=TRUE
  } else {
    problem=FALSE
  }

  if(!is.null(resultJSON) && nchar(resultJSON) > 0 && !problem) {
    result <- rjson::fromJSON(resultJSON)
    searchTypings <- result$searchTypings
    mug <- list()
    for(i in 1:length(searchTypings)) {
      locus <- searchTypings[[i]]$hlaLocus
      # Haplogic uses BPR, turn it into B
      if(locus == 'BPR') locus <- 'B'
      type1 <- searchTypings[[i]]$antigen1
      if( is.null(type1) || type1 == "null") {
        type1 <- ""
      }
      type2 <- searchTypings[[i]]$antigen2
      if( is.null(type2) || type2 == "null") {
        type2 <- ""
      }
      s <- list(locus=locus, type1=type1, type2=type2)
      mug[[i]] <- s
    }

    race <- result$race
    ethn <- result$ethnicity
    racethn <- c(race, ethn)
    age <- result$age
    rhType <- result$rhType
    bloodType <- result$bloodType
    weightInKg <- result$weightInKg
    status <- result$nmdpStatus
    cmvStatus <- result$cmvStatus
    totalNucleatedCellCount <- result$totalNucleatedCellCount
    sex <- result$sex
    population<-result$population
    id <- result$nmdpId
    lastContact <- result$lastDonorContactDate
    cd34 <- result$cd34
    trs <- imputePairForMug(population, mug, host)$trs


    guid <- result$subjectId

    info <- list('id' = id, 'mug'=mug, 'racethn'=racethn, 'guid'=guid, 'age' = age, 'sex'=sex,
                 'rhType' = rhType, 'status'=status,'bloodType' = bloodType,'weightInKg' = weightInKg,
                 'cmvStatus'=cmvStatus, 'totalNucleatedCellCount'=totalNucleatedCellCount,'population'=population,
                 'lastContact'=lastContact, 'cd34'=cd34, 'trs'=trs,
                 'errorStatus'=errorStatus)

    return(info)

  } else {

    info <- list('id' = NA, 'mug'=NA, 'racethn'=NA, 'guid'=guid, 'age' = NA, 'sex'=NA,
                 'rhType' = NA, 'status'=NA,'bloodType' = NA,'weightInKg' = NA,
                 'cmvStatus'=NA,'totalNucleatedCellCount'=NA,'population'=NA,
                 'lastContact'=NA, 'cd34'=NA, 'trs'=NA,
                 'errorStatus'=TRUE)
    return(info)

  }

  NULL

}




#' @title getInfoGUIDs
#' @description Returns a list of data for a patient including for a given GUID list
#' @details Takes in a guid and a host:port and accesses the server to get the corresponding
#'  patients data returning mug, race ethnicity, patient guid, and an error status if there was a problem
#'
#'  @param guids  ID list
#'  @param host Hostname and Port Number of the Server
#'
#'  @return info List of the mug, race ethnicity, patient guid, and an error status
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#'   guids <-c("8c15295c38204fc1ab4ced5898579092","c659fd63f65f4e8a84d4ed5898579092","04563b7777ce483e9848ed5898579092")
#' info <- getInfoGUIDs(guids,'http://p1mri-s1:8080')
#' }
#'
#' @export
#'
getInfoGUIDs <- function(guids, host) {

    url <- paste(host, '/hla/guids/',sep='')
    resultJSON <- NULL
    errorStatus <- FALSE

    if (length(guids) == 1) {
      guids <- list(guids)
    }

    request <- rjson::toJSON(guids)

    reader <- RCurl::basicTextGatherer()
    status <- RCurl::curlPerform(url = url,
                                 httpheader = httpHeaders,
                                 postfields = request,
                                 writefunction = reader$update)

    response <- reader$value()


  if(!is.null(response) && nchar(response) > 0) {

    response <- rjson::fromJSON(response)

    fullResults <- list()

    for (d in 1:length(response)){

      result <- response[[d]]
      guid <- names(response)[d]

      if (!is.null(result)){
          searchTypings <- result$searchTypings
          mug <- list()
          for(i in 1:length(searchTypings)) {
            locus <- searchTypings[[i]]$hlaLocus
            # Haplogic uses BPR, turn it into B
            if(locus == 'BPR') locus <- 'B'
            type1 <- searchTypings[[i]]$antigen1
            if( is.null(type1) || type1 == "null") {
              type1 <- ""
            }
            type2 <- searchTypings[[i]]$antigen2
            if( is.null(type2) || type2 == "null") {
              type2 <- ""
            }
            s <- list(locus=locus, type1=type1, type2=type2)
            mug[[i]] <- s
          }

          race <- result$race
          ethn <- result$ethnicity
          racethn <- c(race, ethn)
          age <- result$age
          rhType <- result$rhType
          bloodType <- result$bloodType
          weightInKg <- result$weightInKg
          status <- result$nmdpStatus
          cmvStatus <- result$cmvStatus
          totalNucleatedCellCount <- result$totalNucleatedCellCount
          sex <- result$sex
          population <- result$population
          id <- result$nmdpId
          lastContact <- result$lastDonorContactDate
          cd34 <- result$cd34
          trs <- imputePairForMug(population, mug, host)$trs
          domestic <-result$domestic
          businessParty <-result$businessParty


          #guid <- result$subjectId

          info <- list('id' = id, 'mug'=mug, 'racethn'=racethn, 'guid'=guid, 'age' = age, 'sex'=sex,
                       'rhType' = rhType, 'status'=status,'bloodType' = bloodType,'weightInKg' = weightInKg,
                       'cmvStatus'=cmvStatus, 'totalNucleatedCellCount'=totalNucleatedCellCount,'population'=population,
                       'lastContact'=lastContact, 'cd34'=cd34, 'trs'=trs, "domestic"= domestic, 'businessParty'=businessParty,
                       'errorStatus'=errorStatus)
      } else {

        info <- list('id' = NA, 'mug'=NA, 'racethn'=NA, 'guid'=guid, 'age' = NA, 'sex'=NA,
                     'rhType' = NA, 'status'=NA,'bloodType' = NA,'weightInKg' = NA,
                     'cmvStatus'=NA,'totalNucleatedCellCount'=NA, 'population'=NA,
                     'lastContact'=NA, 'cd34'=NA, 'trs'=NA,"domestic"= NA, 'businessParty'=NA,
                     'errorStatus'=TRUE)

      }

      fullResults[[guid]] <- info

    }

    return(fullResults)

  }

  NULL

}



#' @title getInfoDID
#' @description Returns a list of data for a patient including for a given DID
#' @details Takes in a did and a host:port and accesses the server to get the corresponding
#'  patients data returning mug, race ethnicity, patient guid, and an error status if there was a problem
#'
#'  @param did  ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return info List of the mug, race ethnicity, patient guid, and an error status
#'
#' @importFrom RCurl getURL
#' @importFrom rjson fromJSON
#'
#' @examples
#' \dontrun{
#' info <- getInfoDID('25730839','http://p1mri-s1:8080')
#' }
#'
#' @export
#'
getInfoDID <- function(did, host) {


  url <- paste(host, '/hla/did/', did, sep='')

  resultJSON <- NULL
  errorStatus <- FALSE

  if ( did == 'invalid') {
    resultJSON=NULL
  } else {
    tryCatch(
      resultJSON <- RCurl::getURL(url, httpheader= httpHeaders),
      error = function(e) {
        message(paste("Failed calling the service at URL", url))
        errorStatus <- TRUE
      })
  }

  if(substr(resultJSON,1,1)=='<') {
    problem=TRUE
  } else {
    problem=FALSE
  }

  if(!is.null(resultJSON) && nchar(resultJSON) > 0 && !problem) {
    result <- rjson::fromJSON(resultJSON)
    searchTypings <- result$searchTypings
    mug <- list()
    for(i in 1:length(searchTypings)) {
      locus <- searchTypings[[i]]$hlaLocus
      # Haplogic uses BPR, turn it into B
      if(locus == 'BPR') locus <- 'B'
      type1 <- searchTypings[[i]]$antigen1
      if( is.null(type1) || type1 == "null") {
        type1 <- ""
      }
      type2 <- searchTypings[[i]]$antigen2
      if( is.null(type2) || type2 == "null") {
        type2 <- ""
      }
      s <- list(locus=locus, type1=type1, type2=type2)
      mug[[i]] <- s
    }

    race <- result$race
    ethn <- result$ethnicity
    racethn <- c(race, ethn)
    age <- result$age
    rhType <- result$rhType
    bloodType <- result$bloodType
    weightInKg <- result$weightInKg
    status <- result$nmdpStatus
    cmvStatus <- result$cmvStatus
    totalNucleatedCellCount <- result$totalNucleatedCellCount
    sex <- result$sex
    population<-result$population
    id <- result$nmdpId
    lastContact <- result$lastDonorContactDate
    cd34 <- result$cd34
    trs <- imputePairForMug(population, mug, host)$trs


    guid <- result$subjectId

    info <- list('id' = did, 'mug'=mug, 'racethn'=racethn, 'guid'=guid, 'age' = age, 'sex'=sex,
                 'rhType' = rhType, 'status'=status,'bloodType' = bloodType,'weightInKg' = weightInKg,
                 'cmvStatus'=cmvStatus, 'totalNucleatedCellCount'=totalNucleatedCellCount,'population'=population,
                 'lastContact'=lastContact, 'cd34'=cd34, 'trs'=trs,
                 'errorStatus'=errorStatus)

    return(info)

  } else {

    info <- list('id' = did, 'mug'=NA, 'racethn'=NA, 'guid'=NA, 'age' = NA, 'sex'=NA,
                 'rhType' = NA, 'status'=NA,'bloodType' = NA,'weightInKg' = NA,
                 'cmvStatus'=NA,'totalNucleatedCellCount'=NA,'population'=NA,
                 'lastContact'=NA, 'cd34'=NA, 'trs'=NA,
                 'errorStatus'=TRUE)
    return(info)

  }

  NULL

}

