
#' parseSireResponse
#'
#' @param response SIRE Response object
#'
#' @importFrom httr status_code content
#'
#' @return Sire result
#'
parseSireResponse <- function(response) {
  # Success
  if (httr::status_code(response) == 200) {
    result <- httr::content(response, as = 'parsed', encoding = 'json')
    return(result)
  } else {
    # Failure
    statusCode <- httr::status_code(response)
    message <- paste("Failed with status:", statusCode);
    warnings(message)
    print(message)
  }

  NULL
}

#' @title getSireForRecipientGuid
#' @description Returns a Sire for a given Recipient Guid
#' @details Takes in a Guid and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param guid Recipient GUID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return sire Returns a vector of all self identified Broad Race groups,
#'    returns \code{NULL} if \code{rid} is not found.
#'
#' @importFrom httr GET accept_json
#'
#' @examples
#' \dontrun{
#' sire <- getSireForRecipientGuid('2985c8419aa1432bbf75efbc51d66cc8','http://p1mri-s1:8080')
#' }
#'
#' @export
getSireForRecipientGuid <- function(guid, host){
  path <- 'sire/rguid/'
  response <- httr::GET(url = host, path = paste0(path, guid), httr::accept_json())
  return(parseSireResponse(response))
}

#' @title getSireForDonorGuid
#' @description Returns a Sire for a given Donor Guid
#' @details Takes in a Guid and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param guid Donor GUID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return sire Returns a vector of all self identified Broad Race groups,
#'    returns \code{NULL} if \code{rid} is not found.
#'
#' @importFrom httr GET accept_json
#'
#' @examples
#' \dontrun{
#' sire <- getSireForDonorGuid('2985c8419aa1432bbf75efbc51d66cc8','http://p1mri-s1:8080')
#' }
#'
#' @export
getSireForDonorGuid <- function(guid, host){
  path <- 'sire/dguid/'
  response <- httr::GET(url = host, path = paste0(path, guid), httr::accept_json())
  return(parseSireResponse(response))
}


#' @title getSireForCbuGuid
#' @description Returns a Sire for a given CBU Guid
#' @details Takes in a Guid and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param guid CBU GUID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return sire Returns a vector of all self identified Broad Race groups,
#'    returns \code{NULL} if \code{rid} is not found.
#'
#' @importFrom httr GET accept_json
#'
#' @examples
#' \dontrun{
#' sire <- getSireForCbuGuid('2985c8419aa1432bbf75efbc51d66cc8','http://p1mri-s1:8080')
#' }
#'
#' @export
getSireForCbuGuid <- function(guid, host){
  path <- 'sire/cguid/'
  response <- httr::GET(url = host, path = paste0(path, guid), httr::accept_json())
  return(parseSireResponse(response))
}


#' @title getDetailedForGuid
#' @description Returns a Detailed Race for a given Guid
#' @details Takes in a Guid and a host:port and accesses the server to get the corresponding
#'  mug and returns the sire
#'
#'  @param guid Patient ID
#'  @param host Hostname and Port Number of the Server
#'
#'  @return detailed Returns the detailed race and ethnicity,
#'    returns \code{NULL} if \code{rid} is not found.
#'
#' @importFrom httr GET accept_json status_code content
#'
#' @examples
#' \dontrun{
#' detailed <- getDetailedForGuid('b57a1cc37f594a81870d263dbb929e71','http://p1mri-s1:8080')
#' }
#'
#' @export
getDetailedForGuid <- function(guid, host){

  path <- 'hla/guid/'
  response <- httr::GET(url = host, path = paste0(path, guid), httr::accept_json())
  # Success
  if (httr::status_code(response) == 200) {
    result <- httr::content(response, as = 'parsed', encoding = 'json')
    race <- result$race
    ethnicity <- result$ethnicity
    population=result$population

    return(c(race, ethnicity, population))
  } else {
    # Failure
    statusCode <- httr::status_code(response)
    message <- paste("Failed with status:", statusCode);
    warnings(message)
    print(message)
  }

  NULL
}

